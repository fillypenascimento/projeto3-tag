# Projeto 3 da disciplina Teoria e Aplicação de Grafos
### Fillype Alves do Nascimento - 16/0070431 e Gabriel dos Santos Martins - 15/0126298
### Para compilar e executar o programa, clone o repositório em um diretório local e digite no terminal os seguintes comandos:   
-  g++ -o projeto3 projeto3.cpp -std=c++11
-  ./projeto3
